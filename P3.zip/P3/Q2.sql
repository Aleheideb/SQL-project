/* Q: Which country spends more on musisc? */

SELECT c.Country, sum(total*unitprice) spent
FROM Customer c
JOIN Invoice i on c.CustomerId = i.CustomerId
JOIN InvoiceLine l on l.InvoiceId= i.InvoiceId
GROUP by c.Country
ORDER by spent DESC
LIMIT 10;
