/* Q: Which music type is the most popular in each country? */

WITH t1 AS (
  SELECT g.Name Name, c.Country Country,  count(total) Purcahses,g.GenreId GenreId
 FROM Genre g
JOIN Track t on t.GenreId = g.GenreId
JOIN InvoiceLine l on l.TrackId= t.TrackId
JOIN Invoice i on i.InvoiceId = l.InvoiceId
JOIN Customer c on c.CustomerId = i.CustomerId
   GROUP by c.Country, g.GenreId
ORDER by c.Country, count(total) DESC, g.Name),
t2 AS (
   SELECT Country, MAX(Purcahses) Purcahses
   FROM t1
   GROUP BY 1)
SELECT t1.Purcahses,t1.Country, t1.Name Type, t1.GenreId
FROM t1
JOIN t2
ON t1.Country = t2.Country AND t1.Purcahses = t2.Purcahses
LIMIT 10;
