/* Q: who wrote the highest number of rock musics? */

SELECT a.ArtistId, a.Name, count(g.Name) songs
FROM Artist a
JOIN Album b on b.ArtistId= a.ArtistId
JOIN Track t on t.AlbumId= b.AlbumId
JOIN Genre g on t.GenreId= g.GenreId
WHERE g.Name = "Rock"
GROUP By a.ArtistId
ORDER By  count(g.Name)DESC
LIMIT 10;
