/* Q: Who is the best customer? */

SELECT c.Country, sum(total) TotalSpent, c.FirstName, c.CustomerId
FROM Customer c
JOIN Invoice i on i.CustomerId= c.CustomerId
GROUP by c.CustomerId
ORDER by sum(total) DESC
LIMIT 10;
